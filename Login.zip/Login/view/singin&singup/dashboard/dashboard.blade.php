@extends('singin&singup.master_singin&up')
@section('mainContent')

@endsection